fn main() {
    match lalrpop::process_root() {
            Ok(_) => {},
            Err(_) => println!("Error: Could not generate parser"),
        }
}
