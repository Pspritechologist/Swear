use std::{collections::HashMap, fmt::Debug, fmt::Display};

use enum_dispatch::enum_dispatch;

pub enum DataType {
	Assembler(Assembler),
	Callback(Callback),
	Object(Object),
}

pub struct Assembler {
	// body: Valuable,
}

impl Assembler {
	pub fn new() -> Self {
		Assembler {}
	}

	pub fn assemble(&self) -> Object {
		unimplemented!()
	}
}

pub struct Callback {
	params: Vec<String>,
}

impl Callback {
	pub fn new(params: Vec<String>) -> Self {
		Callback {
			params,
		}
	}

	// pub fn execute(&self, args: Vec<Valuable>) -> Object {
	// 	unimplemented!()
	// }
}

#[enum_dispatch]
#[derive(Clone)]
pub enum Object {
	Chars,
	Binary,
	Number,
	Array,
	Map,
	Null,
}

impl Debug for Object {
	fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
		write!(f, "{}", self.object_name())
	}
}

impl Display for Object {
	fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
		write!(f, "{}", self.object_name())
	}
}

#[enum_dispatch(Object)]
pub trait ToObject {
	fn to_chars(&self) -> Chars {
		Chars {
			value: self.object_name(),
		}
	}

	fn to_binary(&self) -> Binary {
		Binary::default()
	}

	fn to_number(&self) -> Number {
		Number::default()
	}

	fn to_array(&self) -> Array {
		Array::default()
	}

	fn to_map(&self) -> Map {
		Map::default()
	}

	fn to_null(&self) -> Null {
		Null::default()
	}

	fn object_name(&self) -> String;
}

#[derive(Clone, Default)]
pub struct Chars {
	value: String,
}

impl ToObject for Chars {
	fn to_chars(&self) -> Chars {
		self.clone()
	}

	fn to_binary(&self) -> Binary {
		unimplemented!();
	}

	fn to_number(&self) -> Number {
		unimplemented!();
	}

	fn to_array(&self) -> Array {
		unimplemented!();
	}

	fn to_map(&self) -> Map {
		unimplemented!();
	}

	fn object_name(&self) -> String {
		"Chars".to_string()
	}
}

impl Into<String> for Chars {
	fn into(self) -> String {
		self.value
	}
}

impl From<String> for Chars {
	fn from(value: String) -> Self {
		Chars {
			value,
		}
	}
}

#[derive(Clone)]
pub struct Binary {
	value: bool,
}

impl ToObject for Binary {
	fn to_chars(&self) -> Chars {
		unimplemented!();
	}

	fn to_binary(&self) -> Binary {
		self.clone()
	}

	fn to_number(&self) -> Number {
		unimplemented!();
	}

	fn to_array(&self) -> Array {
		unimplemented!();
	}

	fn to_map(&self) -> Map {
		unimplemented!();
	}

	fn object_name(&self) -> String {
		"Binary".to_string()
	}
}

impl Default for Binary {
	fn default() -> Self {
			Binary { value: true }
	}
}

impl Into<bool> for Binary {
	fn into(self) -> bool {
		self.value
	}
}

impl From<bool> for Binary {
	fn from(value: bool) -> Self {
		Binary {
			value,
		}
	}
}

#[derive(Clone, Default)]
pub struct Number {
	value: f64,
}

impl ToObject for Number {
	fn to_chars(&self) -> Chars {
		unimplemented!();
	}

	fn to_binary(&self) -> Binary {
		unimplemented!();
	}

	fn to_number(&self) -> Number {
		self.clone()
	}

	fn to_array(&self) -> Array {
		unimplemented!();
	}

	fn to_map(&self) -> Map {
		unimplemented!();
	}

	fn object_name(&self) -> String {
		"Number".to_string()
	}
}

impl Into<f64> for Number {
	fn into(self) -> f64 {
		self.value
	}
}

impl From<f64> for Number {
	fn from(value: f64) -> Self {
		Number {
			value,
		}
	}
}

#[derive(Clone, Default)]
pub struct Array {
	value: Vec<Object>,
}

impl ToObject for Array {
	fn to_chars(&self) -> Chars {
		unimplemented!();
	}

	fn to_binary(&self) -> Binary {
		unimplemented!();
	}

	fn to_number(&self) -> Number {
		unimplemented!();
	}

	fn to_array(&self) -> Array {
		self.clone()
	}

	fn to_map(&self) -> Map {
		unimplemented!();
	}

	fn object_name(&self) -> String {
		"Array".to_string()
	}
}

impl Into<Vec<Object>> for Array {
	fn into(self) -> Vec<Object> {
		self.value
	}
}

impl From<Vec<Object>> for Array {
	fn from(value: Vec<Object>) -> Self {
		Array {
			value,
		}
	}
}

#[derive(Clone, Default)]
pub struct Map {
	value: HashMap<String, Object>,
}

impl ToObject for Map {
	fn to_chars(&self) -> Chars {
		unimplemented!();
	}

	fn to_binary(&self) -> Binary {
		unimplemented!();
	}

	fn to_number(&self) -> Number {
		unimplemented!();
	}

	fn to_array(&self) -> Array {
		unimplemented!();
	}

	fn to_map(&self) -> Map {
		self.clone()
	}

	fn object_name(&self) -> String {
		"Map".to_string()
	}
}

impl Into<HashMap<String, Object>> for Map {
	fn into(self) -> HashMap<String, Object> {
		self.value
	}
}

impl From<HashMap<String, Object>> for Map {
	fn from(value: HashMap<String, Object>) -> Self {
		Map {
			value,
		}
	}
}

#[derive(Clone, Default)]
pub struct Null;

impl ToObject for Null {
	fn to_chars(&self) -> Chars {
		unimplemented!();
	}

	fn to_binary(&self) -> Binary {
		unimplemented!();
	}

	fn to_number(&self) -> Number {
		unimplemented!();
	}

	fn to_array(&self) -> Array {
		unimplemented!();
	}

	fn to_map(&self) -> Map {
		unimplemented!();
	}

	fn object_name(&self) -> String {
		"Null".to_string()
	}
}
