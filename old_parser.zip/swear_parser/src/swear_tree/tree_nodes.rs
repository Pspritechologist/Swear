use super::tokens::*;

#[derive(Debug, PartialEq, Eq)]
pub enum Statement {
    Valuable(Valuables),
    Register(Registers),
    Return { },
}

impl Statement {
    pub fn new_valuable(valuable: Valuables) -> Self {
        Self::Valuable(valuable)
    }

    pub fn new_register(register: Registers) -> Self {
        Self::Register(register)
    }

    pub fn new_return() -> Self {
        Self::Return { }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum Valuables {
    RawObject { obj_type: TObject, literal: Option<String> },
    Expression { contents: Vec<Valuables> },
    Identifier { ident: String },
    Callback { },
    Conversion { target: Box<Valuables>, conversion: TObject },
}

impl Valuables {
    pub fn new_raw_object(obj_type: TObject, literal: Option<TLiteral>) -> Self {
        Self::RawObject { obj_type, literal: literal.map(|l| l.0) }
    }

    pub fn new_expression(contents: Vec<Valuables>) -> Self {
        Self::Expression { contents }
    }

    pub fn new_identifier(ident: String) -> Self {
        Self::Identifier { ident }
    }

    pub fn new_callback() -> Self {
        Self::Callback { }
    }

    pub fn new_conversion(target: Valuables, conversion: TObject) -> Self {
        Self::Conversion { target: Box::new(target), conversion }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum Registers {
    Blueprint { },
    Callback { },
    Register { },
}
