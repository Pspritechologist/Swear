use std::fmt::Debug;

// #[derive(Debug)]
// pub enum Tokens {
//     Object(TObject),
//     Body(TBody),
//     Callback(TCall),
//     Register(TRegister),
// }

#[derive(Debug, PartialEq, Eq)]
pub enum TObject {
    Chars,
    State,
    Count,
    Zip,
    Deck,
    Map,
}

// impl Debug for TObject {
//     fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
//         match self {
//             TObject::Chars => write!(f, "Chars"),
//             TObject::State => write!(f, "State"),
//             TObject::Count => write!(f, "Count"),
//             TObject::Zip => write!(f, "Zip"),
//             TObject::Deck => write!(f, "Deck"),
//             TObject::Map => write!(f, "Map"),
//         }
//     }
// }

#[derive(Debug, PartialEq, Eq)]
pub struct TLiteral(pub String);

impl TLiteral {
    pub fn make_literal(s: &str) -> Self {
        // Replace any instances of "~~'" with "~'".
        // Remove the first and last characters (single quotes).
        // Replace any instances of "~'" with "'".
        // TBody::Literal(s.replace("~~'", "'")[1..s.len() - 1].replace("~~'", "'"))
        let mut s = s.to_string();
        s = s.replace(r"~~'", r"~'");
        s = s[1..s.len() - 1].to_string();
        s = s.replace(r"~'", r"'");
        TLiteral(s)
    }
}


// #[derive(Eq, PartialEq)]
// pub enum TBody {
//     ExprL,
//     ExprR,
//     Notice(String),
//     Literal(String),
// }

// impl TBody {
//     #[allow(dead_code)]
//     pub fn make_notice(s: &str) -> TBody {
//         // Always remove the first character (a semicolon) and remove the last if it's a semicolon or newline.
//         TBody::Notice(s[1..s.len() - if s.ends_with('\n') || s.ends_with(';') { 1 } else { 0 }].to_string())
//     }

//     pub fn make_literal(s: &str) -> TBody {
//         // Replace any instances of "\\'" with "\'".
//         // Remove the first and last characters (single quotes).
//         // Replace any instances of "\'" with "'".
//         // TBody::Literal(s.replace("\\'", "'")[1..s.len() - 1].replace("\\'", "'"))
//         let mut s = s.to_string();
//         s = s.replace(r"\\'", r"\'");
//         s = s[1..s.len() - 1].to_string();
//         s = s.replace(r"\'", r"'");
//         TBody::Literal(s)
//     }
// }

// impl Debug for TBody {
//     fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
//         match self {
//             TBody::ExprL => write!(f, "ExprL"),
//             TBody::ExprR => write!(f, "ExprR"),
//             TBody::Notice(s) => write!(f, "Notice({})", s),
//             TBody::Literal(s) => write!(f, "Literal({})", s),
//         }
//     }
// }

// pub enum TCall {
//     Accessor,
//     Injector,
//     Dropper,
// }

// impl Debug for TCall {
//     fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
//         match self {
//             TCall::Accessor => write!(f, "Accessor"),
//             TCall::Injector => write!(f, "Injector"),
//             TCall::Dropper => write!(f, "Dropper"),
//         }
//     }
// }

// pub enum TRegister {
//     Object,
//     Callback,
//     Blueprint,
// }

// impl Debug for TRegister {
//     fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
//         match self {
//             TRegister::Object => write!(f, "Object"),
//             TRegister::Callback => write!(f, "Callback"),
//             TRegister::Blueprint => write!(f, "Blueprint"),
//         }
//     }
// }