pub mod context;
pub mod data_types;
pub mod swear_tree;

use lalrpop_util::lalrpop_mod;
lalrpop_mod!(pub swear);

pub fn main() {
    println!("{:?}", swear::FileParser::new().parse(r"'I~'m escaping text~ ;)~~'$"))
}

#[cfg(test)]
mod tests {
    use super::*;
    use swear_tree::tokens::TBody;

    #[test]
    fn test_notice() {
        assert_eq!(swear::ExpressionParser::new().parse(
            ";Hello, world!").unwrap(), TBody::Notice(
            "Hello, world".to_string()));
        assert_eq!(swear::ExpressionParser::new().parse(
            ";Hello, world!~n").unwrap(), TBody::Notice(
            "Hello, world".to_string()));
        assert_eq!(swear::ExpressionParser::new().parse(
            ";Hello, world!;").unwrap(), TBody::Notice(
            "Hello, world".to_string()));
        assert_eq!(swear::ExpressionParser::new().parse(
            ";Hello, world!~n;").unwrap(), TBody::Notice(
            "Hello, world".to_string()));
    }
    
    #[test]
    fn test_literal() {
        assert_eq!(swear::ExpressionParser::new().parse(
            r"'Hello, world!'").unwrap(), TBody::Literal(
            r"Hello, world!".to_string()));
        assert_eq!(swear::ExpressionParser::new().parse(
            r"'Hello, ~'world~'!'").unwrap(), TBody::Literal(
            r"Hello, 'world'!".to_string()));
        assert_eq!(swear::ExpressionParser::new().parse(
            r"'Th- Th- That~'s all, folks!'").unwrap(), TBody::Literal(
            r"Th- Th- That's all, folks!".to_string()));
        assert_eq!(swear::ExpressionParser::new().parse(
            r"'Escaping is done with a ~'~~~'. It would look like this. ~'Quote(~~~')~'. You cannot escape other characters, like ~'~.~', or ~'~$~'. To stop a ~ from escaping a closing ~', use a second ~, such as ~' a ~~~' (BROKEN). That~'s why we like the ~~'").unwrap(), TBody::Literal(
            r"Escaping is done with a '~'. It would look like this. 'Quote(~')'. You cannot escape other characters, like '~.', or '~$'. To stop a ~ from escaping a closing ', use a second ~, such as ' a ~' (BROKEN). That's why we like the ~".to_string()));
    }
}
