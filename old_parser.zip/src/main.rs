fn main() {
    swear_parser::main();
}

#[cfg(test)]
mod tests {
    use swear_parser::swear;
    use swear_parser::swear_tree::tree_nodes::{Statement, Valuables};
    
    #[test]
    fn test_parse_literal() {
        assert_eq!(get_literal_from_parse(r"
            'Hello, world!'$
        "),
            r"Hello, world!".to_string());

        assert_eq!(get_literal_from_parse(
            r"'Hello, ~'world~'!'$"
        ),
            r"Hello, 'world'!".to_string());

        assert_eq!(get_literal_from_parse(
            r"'Th- Th- That~'s all, folks!'$"
        ),
            r"Th- Th- That's all, folks!".to_string());

        assert_eq!(get_literal_from_parse(
            r"'Escaping is done with a ~'~~~'. It would look like this. ~'Quote(~~~')~'. You cannot escape other characters, like ~'~.~', or ~'~$~'. To stop a ~ from escaping a closing ~', use a second ~, such as ~' a ~~~' (BROKEN). That~'s why we like the ~~'$"
        ),
            r"Escaping is done with a '~'. It would look like this. 'Quote(~')'. You cannot escape other characters, like '~.', or '~$'. To stop a ~ from escaping a closing ', use a second ~, such as ' a ~' (BROKEN). That's why we like the ~".to_string());
    }

    #[test]
    fn test_parse_notice() {
        let parser = swear::FileParser::new();

        assert!(parser.parse(r"
            ;Hello, world!
            'Test'$
        ").unwrap().len() == 1);
        assert!(parser.parse(r"
            ;Hello, world!

        ").unwrap().is_empty());
        assert!(parser.parse(r"
            ;Hello, world!; 'Test'$
        ").unwrap().len() == 1);
        assert!(parser.parse(r"
            ;Hello, world!
            'Test'$ ;"
        ).unwrap().len() == 1);
        assert!(parser.parse(r"
            ;'Hello, world!'$
            'Test'$
        ").unwrap().len() == 1);
    }

    fn get_literal_from_parse(test: &str) -> String {
        let Statement::Valuable(Valuables::RawObject { obj_type: _, literal: result }) = 
            &swear::FileParser::new()
                .parse(test)
                .unwrap()[0] else { panic!() };
        result.clone().unwrap()
    } 
}
